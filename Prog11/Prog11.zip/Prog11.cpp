/*--------------- P r o g 11 . c p p ---------------

by:   George Cheney
      16.322 Data Structures
      ECE Dept.
      UMASS Lowell

PURPOSE
Find the shortest path through a maze.

CHANGES
10-19-2011 gpc -- Created for 16.322 class.
*/

/*
MODIFIED BY: JESSE WHITWORTH
12/15/2011
*/

#include <stdlib.h>
#include <iostream>

using namespace std;

#include "Utility.h"
#include "Queue_T.h"
#include "Maze.h"

/*-----  O p e n N e i g h b o r () -----
PURPOSE
Attempt to find a neighbor cell that is open.
*/
Position OpenNeighbor(Maze &maze, Position &curPos)
{
	Position emptyPos;
	if (maze.State(curPos + StepEast) == Open){
		return curPos + StepEast;
	}else if (maze.State(curPos + StepSouth) == Open){
		return curPos + StepSouth; //Return updated position
	}else if (maze.State(curPos + StepWest) == Open){
		return curPos + StepWest;
	}else if (maze.State(curPos + StepNorth) == Open){
		return curPos + StepNorth; //Return updated position
	}else
		return emptyPos;
}

/*----- S o l v e M a z e () -----

PURPOSE
Attempt to find the shortest path through the maze.

*/
bool SolveMaze(Maze &maze, Queue<Position> &positionQueue)
{
	positionQueue.Enqueue(maze.Start()); 
	maze.Mark(positionQueue.Head(),0); 
	Position curPos = positionQueue.Head();
	while(!positionQueue.Empty()) 
	{
		while((curPos = OpenNeighbor(maze,positionQueue.Head())).Defined()) 
		{
			maze.Mark(curPos, ((maze.State(positionQueue.Head())) + 1) ); 
			if(curPos == maze.Goal()){
				return true;
			}
			positionQueue.Enqueue(curPos);
		}
		positionQueue.Dequeue();
	}
   return false;
}

/*----- R e t r a c e P a t h (  ) -----
PURPOSE
Mark the path from the goal to the start cell.
*/
void RetracePath(Maze &maze) 
{
	Position curPos = maze.Goal(); // Set the current position to the goal position.
	CellState curState = maze.State(maze.Goal()); // Set the current state to the goal position state.
	maze.Mark(maze.Goal(),-5); // Mark the goal position part of the shortest path.
	curState -= 1; // Decrease the distance of the shortest path.
	do{
		if (maze.State(curPos + StepEast) == curState){
			maze.Mark((curPos + StepEast),-5); 
			curPos += StepEast; 
		}else if (maze.State(curPos + StepSouth) == curState){
			maze.Mark((curPos + StepSouth),-5);
			curPos += StepSouth; 
		}else if (maze.State(curPos + StepWest) == curState){
			maze.Mark((curPos + StepWest),-5); 
			curPos += StepWest; 
		}else if (maze.State(curPos + StepNorth) == curState){
			maze.Mark((curPos + StepNorth),-5);
			curPos += StepNorth;
		}
		curState -= 1;
	}while(curState != maze.State(maze.Start())); 
	maze.Mark(maze.Start(),-5); 
}

/*--------------- m a i n ( ) ---------------*/

void main(void)
{
	// Screen positions
	const unsigned XResult = 35;
	const unsigned YResult = 5;
	const unsigned XFinish = 35;
	const unsigned YFinish = 10;

	for (;;){
		// Construct a maze from a maze definition file.
		Maze  maze;

		// Queue of future positions to visit
		Queue<Position> positionQueue;
		// Solve the maze.
		bool success = SolveMaze(maze, positionQueue);
		// Indicate success or failure.
		gotoxy(XResult, YResult);

		if (!success)
			cout << "Failed: No path from start to goal exists." << endl;
		else{
			cout << "Success: Found the shortest path." << endl;
			gotoxy(XResult, YResult+2);
			cout << "Press ENTER to highlight the shortest path.";
			cin.get();

			RetracePath(maze);
		}

		// Done
		gotoxy(XFinish, YFinish);
		cout << "Press ENTER to continue...";
		cin.get();
		clrscr();
		}
}