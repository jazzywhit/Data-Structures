//
//  Stack.cpp
//  Prog5
//
//  Created by JESSE WHITWORTH on 10/22/11.
//  Copyright 2011 Jesse Whitworth. All rights reserved.
//
//  A linked list stack class.
//

#include<iostream>
using namespace std;
#include "Stack.h"

// -------------------- P U S H () ------------------------
// Push a new element onto the top of the stack.
void Stack::Push(const StackElement &p){
	stack.Insert(p);
	size += 1;
}

// -------------------- P O P () ------------------------
// Pop off the top of the stack.
StackElement Stack::Pop(){
	FindEnd();
	stack.Delete();
	size -= 1;
	FindEnd();
	return stack.CurrentEntry();
}

// -------------------- T O P () ------------------------
// UNABLE TO USE THIS FUNCTION.
// This function does not work because the obj file that you supplied 
// does not update stack->current when Insert() is called. This required 
// that I make a number of additions to this program that are unnecessary. 
// Please provide a working .obj for us if you don't want us to use our own
// LinkedList. 
StackElement Stack::Top() const{
	return stack.CurrentEntry();
}

// -------------------- F i n d E n d () -----------------
// Helper function to get to the top of the list. This could be in the Top() 
// definition except that there was a requirement that Top be const. 
void Stack::FindEnd(){
	stack.Rewind();
	for(int i = 0; i < size-1; i++){
		stack.Skip();
	}
}