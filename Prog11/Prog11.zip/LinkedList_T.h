#ifndef LINKEDLIST_T_H
#define LINKEDLIST_T_H

//----- L i n k e d L i s t -----
// Linked List Template class
/*
MODIFIED BY: JESSE WHITWORTH
12/15/2011
*/

#include <cassert>

//----- C l a s s L i n k e d L i s t -----
template <typename NodeData>
class LinkedList
{ 
	protected:
		// List node class definition
		struct Node
		{
			NodeData data; // The "contents" of the node
			Node *next; // Link to the next node
			// Node Constructor Functions
			Node(){}
			Node(const NodeData &theData, const Node *theNext = 0)
			: data(theData), next((Node *)theNext) { }
		};
	public:
		// Constructors
		LinkedList() : first(0), current(0), pred(0) {}; // Constructor
		//Copy Constructor
		LinkedList(LinkedList &source);
		// Destructor
		~LinkedList();
		void Clear(); //Clear the list of all nodes.
		// Overloaded assignment operator
		LinkedList operator=(LinkedList &right);// True if the list is empty
		bool Empty() const { return first == 0; };
		// True if the current position is beyond the last entry.
		bool AtEnd() const;
		// Rewind the current entry to the beginning of the list.
		void Rewind() { current = first; pred = 0; }
		// Skip to the next entry in the list.
		void Skip();
		// Get the contents of the current list entry.
		NodeData CurrentEntry() const;
		// Insert a new list entry before the current entry.
		void Insert(const NodeData &d);
		// Update the current entry.
		void Update(const NodeData &d) { assert(!AtEnd()); current->data = d; }
		//Delete the current entry.
		//The new current entry is the successor of the deleted node.
		void Delete();
	private:
		// Make this list a copy of source.
		void DeepCopy(LinkedList &source);
	protected:
		Node *first; // Points to the first node in the list
		Node *current; // Points to the current node
		Node *pred; // Points to the node preceding the current entry.
};

/*---------------------- C o p y C o n s t r u c t o r ------------------------
Purpose: Used to construct a linked list from the source linked list.
*/

template <typename NodeData>
LinkedList<typename NodeData>::LinkedList( LinkedList &source )
{
	DeepCopy(source);	//Initialize copy of list with source list.
}

/*---------------o p e r a t o  r = ( ) ---------------------
Purpose: Used to assign the source list the the copy list.
*/
template <typename NodeData>
LinkedList<typename NodeData> LinkedList<typename NodeData>::operator=(LinkedList &right)
{
	if( this != &right){
		Rewind(); 
		Clear(); 
		DeepCopy(right); 
	}
	return *this; // Return the copy list. 
}

/*---------------- ~ L i n k e d L i s t ( ) ----------------------- 
Purpose: Used to dealocate the dynamically allocated memory associated to Linked List.
*/

template <typename NodeData>
LinkedList<typename NodeData>::~LinkedList()
{
	Rewind(); // Send List Back to beginning
	Clear();
}

/*---------------- C l e a r ( ) ----------------------- 
Purpose: Used to clear a list of all nodes.
*/

template <typename NodeData>
void LinkedList<typename NodeData>::Clear()
{
	Rewind();
	while (!Empty()){
		Delete();
	}
}

/*------------------- A t E n d ( ) ----------------------------
Purpose: Used to find if the end of the list has been reached.
*/

template <typename NodeData>
bool LinkedList<typename NodeData>::AtEnd() const
{
	if( current == 0 ) // At end of list the current entry is null.
		return true; // End of list
	else
		return false; // Not end of list
}

/*--------------------- I n s e r t () ----------------------------*/
template <typename NodeData>
void LinkedList<typename NodeData>::Insert(const NodeData &d)
{
	Node *temp;
	assert(temp = new(nothrow) Node()); // Create a temporary node.
	temp->data = d; // Insert data into node.
	if( pred == 0 ) // Beginning of the list 
	{
		current = first;
		temp->next = first; // Temp node points to what first node pointed to.
		first = temp; // First points to the temp node.
		pred = temp; // The previous node is now the temp node because inserted at beginning.
	}
	else // Not beginning of list.
	{
		temp->next = current; // Temp now points to what current pointed to.
		pred->next = temp; // The previous entry now points to temp. 
		pred = temp; // The previous entry is now the temp entry before the current entry.
	}
}

/*--------------- S k i p ( ) ---------------------------------
Purpose: Used to skip an entry in the list.
*/

template <typename NodeData>
void LinkedList<typename NodeData>::Skip()
{
	assert(!AtEnd()); // Cannot skip if you are at the end of the list.
	pred = current; // Previous entry is now the current entry
	current = current->next; // Current entry is now the next entry.
}

/*------------------ C u r r e n t E n t r y ( ) ----------------------------
Purpose: Returns the Current Entry. 
*/

template <typename NodeData>
NodeData LinkedList<typename NodeData>::CurrentEntry() const
{
	assert(current != 0);
	return current->data;
}

/*------------------------ D e l e t e () -------------------------------*/
template <typename NodeData>
void LinkedList<typename NodeData>::Delete()
{
	assert( current != 0); 
	if( pred == 0 ){
		first = current->next;
		delete current; 
		current = first; 
	}else{
		pred->next = current->next; 
		delete current; 
		current = pred->next; 
	}
}

#endif