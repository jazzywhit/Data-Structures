#ifndef QUEUE_T_H
#define QUEUE_T_H

//----- Q u e u e -----
// Queue Template class
// Inherits from template "LinkedList_T.h"
/*
MODIFIED BY: JESSE WHITWORTH
12/15/2011
*/

#include "LinkedList_T.h"

template <typename ElemData>
class Queue : public LinkedList<ElemData>
{
	public:
		// Construct an empty queue.
		Queue() : last(0) { }
		// Add "elem" at the tail of the queue.
		void Enqueue(const ElemData &elem);
		// Remove and return the head element.
		ElemData Dequeue();
		// Return, but do not remove the head element.
		ElemData Head();
	private:
		// Points to the last (tail) node of the queue
		Node *last;
};

//Enqueue
template <typename ElemData>
void Queue<typename ElemData>::Enqueue(const ElemData &data)
{
	current = last;
	if(!Empty()) Skip();
	Insert(data);
	last = pred;
}

//Dequeue
template <typename ElemData>
ElemData Queue<typename ElemData>::Dequeue()
{
	Rewind();
	ElemData head = CurrentEntry();
	Delete();
	return head;
}

//Enqueue
template <typename ElemData>
ElemData Queue<typename ElemData>::Head()
{
	return first->data;
}


#endif