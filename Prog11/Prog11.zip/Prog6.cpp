/*--------------- P r o g 6 . c p p ---------------

by:   George Cheney
      16.322 Data Structures
      ECE Dept.
      UMASS Lowell

PURPOSE
Find the shortest path through a maze.

CHANGES
10-19-2011 gpc -- Created for 16.322 class.
*/

#include <stdlib.h>
#include <iostream>

using namespace std;

#include "Utility.h"
#include "Maze.h"

const bool SUCCESS = true;
const bool FAILURE = false;


/*-----  ( O p e n N e i g h b o r ) -----

PURPOSE
Attempt to find a neighbor cell that is open.

INPUT PARAMETERS
maze           -- the maze object to be traversed.
curPos		   -- the currant position in the maze.

RETURN VALUE
Position	   -- the updated position.
*/
Position OpenNeighbor(Maze &maze, Position &curPos)
{
	Position dud; // Dud point not defined to return error.
	if (maze.State(curPos + StepEast) == Open) // If there is an open spot of the east
		{
			return curPos + StepEast; //Return updated position
		}
	else if (maze.State(curPos + StepSouth) == Open) // If there is an open spot of the east
		{
			return curPos + StepSouth; //Return updated position
		}
	else if (maze.State(curPos + StepWest) == Open) // If there is an open spot of the east
		{
			return curPos + StepWest; //Return updated position
		}
	else if (maze.State(curPos + StepNorth) == Open) // If there is an open spot of the east
		{
			return curPos + StepNorth; //Return updated position
		}
	else
		return dud; // Return error.
}

/*----- S o l v e M a z e (  ) -----

PURPOSE
Attempt to find the shortest path through the maze.

INPUT PARAMETERS
maze           -- the maze object to be traversed
positionQueue  -- the queue of current and future positions

RETURN VALUE
true  -- a path was found.
false -- failed to find a path.
*/
bool SolveMaze(Maze &maze, Queue &positionQueue)
{
	Position curPos = maze.Start(); // The current position is the start
	positionQueue.Enqueue(curPos); // Put the start position in the queue.
	maze.Mark(positionQueue.Head(),0); //Mark the distance from start 0.
	while(!positionQueue.Empty()) //While the queue is not empty.
	{
		while((curPos = OpenNeighbor(maze,positionQueue.Head())).Defined()) // While currant position has any open neighbors. 
		{
			maze.Mark(curPos, ((maze.State(positionQueue.Head())) + 1) ); // Mark the open neighbor with the new distance from start.
			if(curPos == maze.Goal()) //If this position is the goal position.
			{
				return SUCCESS; //You have succeded 
			}
			positionQueue.Enqueue(curPos); // put current position in Queue.
		}
		positionQueue.Dequeue(); //remove the head of the queue.
	}
   return FAILURE; // No path exists.
}

/*----- R e t r a c e P a t h (  ) -----

PURPOSE
Mark the path from the goal to the start cell.

INPUT PARAMETERS
maze           -- the maze object to be marked
*/
void RetracePath(Maze &maze) 
{
	Position curPos = maze.Goal(); // Set the current position to the goal position.
	CellState curState = maze.State(maze.Goal()); // Set the current state to the goal position state.
	maze.Mark(maze.Goal(),-5); // Mark the goal position part of the shortest path.
	curState -= 1; // Decrease the distance of the shortest path.
	do
	{
		if (maze.State(curPos + StepEast) == curState) // If there is a position the east needed to be included in shortest path.
		{
			maze.Mark((curPos + StepEast),-5); //Mark this position.
			curPos += StepEast; //Update the current position.
		}
		else if (maze.State(curPos + StepSouth) == curState) // If there is a position the south needed to be included in shortest path.
		{
			maze.Mark((curPos + StepSouth),-5); //Mark this position.
			curPos += StepSouth; //Update the current position.
		}
		else if (maze.State(curPos + StepWest) == curState) // If there is a position the west needed to be included in shortest path.
		{
			maze.Mark((curPos + StepWest),-5); //Mark this position.
			curPos += StepWest; //Update the current position.
		}
		else if (maze.State(curPos + StepNorth) == curState) // If there is a position the north needed to be included in shortest path.
		{
			maze.Mark((curPos + StepNorth),-5); //Mark this position.
			curPos += StepNorth; //Update the current position.
		}
		curState -= 1; // Decrease the distance of the shortest path.
	}while(curState != maze.State(maze.Start())); // If the distance of the shortest path is the same as the start position, all done marking path.
	maze.Mark(maze.Start(),-5); // Mark the start position part of the shortest path. 
}

/*--------------- m a i n ( ) ---------------*/

void main(void)
{
   // Screen positions
   const unsigned XResult = 35;
   const unsigned YResult = 5;
   const unsigned XFinish = 35;
   const unsigned YFinish = 10;

	for (;;)
		{
	   // Construct a maze from a maze definition file.
	   Maze  maze;

	   // Queue of future positions to visit
	   Queue positionQueue;

		// Solve the maze.
		bool success = SolveMaze(maze, positionQueue);

		// Indicate success or failure.
		gotoxy(XResult, YResult);

		if (!success)
			cout << "Failed: No path from start to goal exists." << endl;
		else
			{
			cout << "Success: Found the shortest path." << endl;
			gotoxy(XResult, YResult+2);
			cout << "Press ENTER to highlight the shortest path.";
			cin.get();

			RetracePath(maze);
			}

		// Done
		gotoxy(XFinish, YFinish);
		cout << "Press ENTER to continue...";
		cin.get();
		clrscr();
		}
}